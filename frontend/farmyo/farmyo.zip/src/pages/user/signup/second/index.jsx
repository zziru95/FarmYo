import SignUpSecond from "../../../../component/user/signUp/second"

export default function SignUpSecondPage () {
  return (
    <div>
      <SignUpSecond />
    </div>
  )
}