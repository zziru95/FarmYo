import SignUpThird from "../../../../component/user/signUp/third"

export default function SignUpThirdPage () {
  return (
    <div>
      <SignUpThird />
    </div>
  )
}