import SignUpFirst from "../../../../component/user/signUp/first"

export default function SignUpFirstPage () {
  return (
    <div>
      <SignUpFirst />
    </div>
  )
}