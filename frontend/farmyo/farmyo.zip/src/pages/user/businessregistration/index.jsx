import Business from "../../../component/user/businessregistration/index"
// import Business from "component/user/businessregistration"

export default function BusinessPage () {
  return (
    <div>
      <Business />
    </div>
  )
}